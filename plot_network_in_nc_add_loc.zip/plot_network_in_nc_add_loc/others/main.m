runpf(data48_matpower)
for loop = 1 : 140
    Binary_exact_lambda(data48_matpower,loop)
end