%runpf(data48_matpower)
for loop = 1 : 228
    Binary_exact_lambda(case_germany,loop)
end