function case_GB_reduced = case_GB 
load case_GB_reduced
end